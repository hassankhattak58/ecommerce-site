// Function To Change Descrition Types In Product Page 
let btns = document.querySelectorAll(".tab-btn");
let boxes = document.querySelectorAll(".description-tabs");

btns.forEach((btn, index) => {
    btn.addEventListener('click', (e) => {
        btns.forEach(btns => { btns.classList.remove("active-tab-product") });
        btn.classList.add("active-tab-product");

        boxes.forEach(box => { box.classList.remove("product-info-display"); })
        boxes[index].classList.add("product-info-display");
    })
})



// Function to Display Cart 
let cart = document.querySelector(".cart");
let btcartRight = document.querySelector(".cart-right");
let cartMenu = document.querySelectorAll(".cart-menu");


cartMenu.forEach(menu => {
    menu.addEventListener('click', () => {
        cart.classList.toggle("cart-active");
        btcartRight.classList.toggle("card-right-active");
        document.body.classList.toggle("lock-scroll");
    })

})