// Full Screen Image Function 
const img = document.querySelector(".product-image");
const container = document.querySelector(".full-screen-image");
const containerImg = document.querySelector(".full-screen-image img");

img.addEventListener("click", () => {
    containerImg.src = img.src;
    document.body.classList.toggle("lock-scroll");
    container.classList.toggle("full-screen-block");
});

container.addEventListener("click", () => {
    document.body.classList.toggle("lock-scroll");
    container.classList.toggle("full-screen-block");
})